// Write JavaScript here 
console.log({ myMessage: msg });
console ("Primera página");